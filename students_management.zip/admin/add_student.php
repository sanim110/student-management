<?php

include('../database.php');
// include('check_login.php');


 if(isset($_POST['submit'])){
    $data = $_POST;
    $name = $data['name'];
    $roll = $data['roll'];
    $city = $data['city'];
    $contact = $data['contact'];
    $class = $data['class'];

    $phone_no_count = strlen($contact);


    if (empty($name)) {
        $name_error ="* This field is required to fill";
    }

    if (empty($roll)) {
        $roll_error ="* This field is required to fill";
    }    
    if (empty($city)) {
        $city_error ="* This field is required to fill";
    }    
    if (empty($contact)) {
        $contact_error ="* This field is required to fill";
    }   
    if (empty($class)) {
        $class_error ="* Select a class";
    } 
    if ($phone_no_count != 11) {
        $contact_error ="* Write a valid number";
    } 
    if(isset($_FILES['picture'])){
        $img = $_FILES['picture']['name'];
        $explode = explode('.',$img);
        $extension = end($explode);
        $rename = date('dmyhis').'.'.$extension;
    }
    
    if (!empty($name) && !empty($roll) && !empty($city) && !empty($contact) && !empty($class) && ($phone_no_count == 11)){
        $insert_query = "INSERT INTO `student`(`name`, `roll`, `city`, `contact`,`class`,`photo`) VALUES ('$name','$roll ','$city','$contact','$class','$rename')";
        $result = $conn->query($insert_query); 
        if($result == true){
            header('location:all_student.php');
        }
        move_uploaded_file($_FILES['picture']['tmp_name'], 'img/'.$rename);  
    }
}
?>




<?php
     include('head.php');
?>
<body>
    <?php
     include('header.php');
    ?>
     
    <style>
        .addstudent, .addstudent a {
            color: #fff;
            background-color: #006DCB;
            border: none;
        }
    </style>
    <div class="row m-0">
        <?php include('sidebar.php');?>
        <div class="col-sm-12 col-md-8 col-lg-9">
            <!--------------- add student start -------------->
        <section class="add-student section">
            <div class="section_title">
                <h4><span><i class="fa-solid fa-user-plus"></i>Add Students</span>Add Students</h4>
            </div>
            <div class="row">
                <div class="col-md-12 col-lg-6">
                    <div class="form-container">
                        <form method="POST" enctype="multipart/form-data">
                            <div>
                                <label>Student Name:</label>
                                <div class="text-danger"><?php if (isset($name_error)){echo($name_error);}?></div>
                                <input type="text" id="student-name" placeholder="Student Name" name="name" value="<?php if (isset($name)){echo($name);}?>">
                            </div>
                
                            <div>
                                <label>Student Roll:</label>
                                <div class="text-danger"><?php if (isset($roll_error)){echo($roll_error);}?></div>
                                <input type="text" id="student-roll" placeholder="Student Roll" name="roll" value="<?php if (isset($roll)){echo($roll);}?>">
                            </div>
                
                            <div>
                                <label>City Name:</label>
                                <div class="text-danger"><?php if (isset($city_error)){echo($city_error);}?></div>
                                <input type="text" id="city-name" placeholder="City" name="city" value="<?php if (isset($city)){echo($city);}?>">
                            </div>
                
                            <div>
                                <label>Personal Contact:</label>
                                <div class="text-danger"><?php if (isset($contact_error)){echo($contact_error);}?></div>
                                <input type="text" id="contact" placeholder="Personal Contact" name="contact" value="<?php if (isset($contact)){echo($contact);}?>">
                            </div>
                
                            <p>We'll never share your contact number with anyone else</p>
                
                            <div>
                                <label>Class:</label>
                                <div class="text-danger"><?php if (isset($class_error)){echo($class_error);}?></div>
                                <select name="class" value="<?php if (isset($class)){echo($class);}?>">
                                    <option value="">Select Class</option>
                                    <option value="1" <?php if (isset($class) && $class == 1){echo('selected');}?>>6</option>
                                    <option value="2" <?php if (isset($class) && $class == 2){echo('selected');}?>>7</option>
                                    <option value="3" <?php if (isset($class) && $class == 3){echo('selected');}?>>8</option>
                                </select>
                            </div>
    
                            <div>
                                <label for="profile-picture">Choose Picture:</label>
                                <input type="file" name="picture" id="profile-picture" accept="image/*">
                            </div>
                
                            <div>
                                <!-- <button class="btn btn-primary"><input type="submit" name="submit"> Add Student</button> -->
                                 <input class="btn btn-primary" type="submit" value="Add Student" name="submit">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!--------------- add student end -------------->

        </div>
    </div>
  


    
<?php include('footer.php'); ?>