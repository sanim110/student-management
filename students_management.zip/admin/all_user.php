<?php
     include('head.php');
     include('../database.php');
?>
<body>
    <?php
     include('header.php');
    ?>
    <style>
        .alluser, .alluser a {
            color: #fff;
            background-color: #006DCB;
            border: none;
        }
    </style>

    <div class="row m-0">
        <?php include('sidebar.php');?>
        <div class="col-sm-12 col-md-8 col-lg-9">
            <!--------------- all student start -------------->
        <section class="all-student section" id="all-student">
            <div class="section_title">
                <h4><span><i class="fa-solid fa-users"></i>All Users</span>All Users</h4>
            </div>
            <div class="table-container">
                <h4>All Users</h4>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>User Name</th>
                            <th>Photo</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $users ="SELECT * FROM `user`";
                        $all_users= $conn->query($users);
                        while ($row = mysqli_fetch_assoc($all_users)){
                            
                        
                        ?>
                        <tr>
                            <td><?php echo ($row['id']); ?></td>
                            <td><?php echo ($row['name']); ?></td>
                            <td><?php echo ($row['email']); ?></td>
                            <td><?php echo ($row['user_name']); ?></td>
                            <td><img width="100px" src="img/<?php echo ($row['photo']); ?>"></td>
                            <td>
                                <div class="mb-1"><a href="edit_profile.php"><button class="btn btn-primary">Edit</button></a></div>
                                <div><a onclick="handleDeleteConfirmation(<?php echo ($row['id']); ?>)"><button class="btn btn-danger">Delete</button></a></div>
                            </td>
                        </tr>
                        <?php
                         }
                        ?>
                    </tbody>
                </table>
            </div>
        </section>
        <!--------------- all student end -------------->

        </div>
    </div>
  
    <script>
        function handleDeleteConfirmation(id){
        Swal.fire({
            title: "Do you want to save the changes?",
            showDenyButton: false,
            showCancelButton: true,
            confirmButtonText: "Delete",
        }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            Swal.fire("Delete Successfull!", "", "success");
            redirectSomeTimeLater(id);
        }
     });

      }
      function redirectSomeTimeLater(id){
          setTimeout(function(){
            window.location.href="delete_user.php?id="+id;
          },2000);
      }
  </script>

    
    
<?php include('footer.php'); ?>