<?php
     include('head.php');
     include('check_login.php');
     include('../database.php');


     $user = "SELECT * FROM `user`";
     $userCount = $conn->query($user);
     $userCount = mysqli_num_rows($userCount);


     $students = "SELECT * FROM `student`";
     $stdsCount = $conn->query($students);
     $stdsCount = mysqli_num_rows($stdsCount);
?>
<body>
    <?php
     include('header.php');
    ?>
    <style>
        .dashbor, .dashbor a {
            color: #fff;
            background-color: #006DCB;
            border: none;
        }
    </style>

    <div class="row m-0">
        <?php include('sidebar.php');?>
        <div class="col-sm-12 col-md-8 col-lg-9">
            <!--------------- dashbord star -------------->
            <section class="dashbord section" >
                <div class="section_title" id="dashbord">
                    <h4><span><i class="fa-solid fa-gauge-high"></i>Dashbord</span>Statistics Overview</h4>
                </div>
                <div class="dashbord_bar">
                    <h5>Dashbord</h5>
                </div>
                <div class="dashbord_content">
                    <div class="row m-0">
                        <div class="col-sm-12 col-md-6 col-lg-6">
                            <a href="all_user.php">
                            <div class="dashbord_box">
                                <div class="dashbord_icon bg-primary p-4 d-flex justify-content-between align-items-center">
                                    <span><i class="fa-solid fa-users fa-4x  text-light"></i></span>
                                    <div class="dashbord_count text-light">
                                        <span><?php echo $userCount;?></span>
                                        <p>All Users</p>
                                    </div>
                                </div>
                                <div class="dashbord_user d-flex justify-content-between align-items-center p-3">
                                    <a href="#">View All Users</a>
                                    <span><i class="fa-solid fa-arrow-right text-light"></i></span>
                                </div>
                            </div>
                            </a>
                        </div>
                        <div class="col-sm-12 col-md-6 col-lg-6">
                        <a href="all_student.php">
                        <div class="dashbord_box">
                            <div class="dashbord_icon bg-primary p-4 d-flex justify-content-between align-items-center">
                                <span><i class="fa-solid fa-user-graduate fa-4x text-light"></i></span>
                                <div class="dashbord_count text-light">
                                    <span><?php echo $stdsCount;?></span>
                                    <p>All Students</p>
                                </div>
                            </div>
                            <div class="dashbord_user d-flex justify-content-between align-items-center p-3">
                                <a href="#">View All Students</a>
                                <span><i class="fa-solid fa-arrow-right text-light"></i></span>
                            </div>
                        </div>
                        </a>
                        </div>
                    </div>
                </div>
            </section>
        <!--------------- dashbord end -------------->
        </div>
    </div>
  


    
    
<?php include('footer.php'); ?>