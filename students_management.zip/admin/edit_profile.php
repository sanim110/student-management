
<?php
include('head.php');
include('../database.php');

$current_user = $_SESSION['admin_logined'];
$userQuery = "SELECT * FROM `user` WHERE `user_name` = '$current_user'";
$result = $conn->query($userQuery);
$row = mysqli_fetch_assoc($result);


    

  
?>
<body>
    <style>
        .user-profile_bar{
            background: gainsboro;
        }
    </style>
    <?php
     include('header.php');
    ?>
     
    <div class="row m-0">
        <?php include('sidebar.php');?>
        <div class="col-sm-12 col-md-8 col-lg-9">
            <!-- ------------- user profile start -------------->
        <section class="user-profile section">
            <div class="section_title">
                <h4><span><i class="fa-solid fa-user"></i>Edit Profile</span>Edit Profile</h4>
            </div>
            <div class="user-profile_bar">
                <h5 class="text-center">Edit Your Profile</h5>
            </div>
            <div class="row">
                <div class="col-md-12 col-lg-6">
                    <?php
                    if(isset($_POST['submit'])){
                        $name = $_POST['name'];
                        $email = $_POST['email'];
                        $user = $_POST['user'];
                        $update_qiery = "UPDATE `user` SET `name`='$name',`email`='$email',`user_name`='$user' WHERE `user_name` = '$current_user'";
                        $result = $conn->query($update_qiery);
                        if($result){
                            header('location:user_profile.php');
                        }
                    }
                    ?>
                    <div class="form-container">
                        <form method="POST">
                            <div>
                                <label>Name:</label>
                                <div class="text-danger"><?php if (isset($name_error)){echo($name_error);}?></div>       
                                <input type="text" id="student-name" placeholder="Write Your Name" name="name" value="<?php echo $row['name']; ?>">
                            </div>
                
                            <div>
                                <label>Email:</label>
                                <div class="text-danger"><?php if (isset($email_error)){echo($email_error);}?></div>
                                <input type="email" id="email" placeholder="Write Your Email" name="email" value="<?php echo $row['email'];?>">
                            </div>
                
                            <div>
                                <label>User Name:</label>
                                <div class="text-danger">
                            </div>
                            <div class="text-danger"><?php if (isset($user_error)){echo($user_error);}?></div>
                                <input type="text" id="user-name" placeholder="Write Your Username" name="user" value="<?php echo $row['user_name'];?>">
                            </div>
                            <div>
                                <!-- <button class="btn btn-primary"><input type="submit" name="submit"> Add Student</button> -->
                                 <input class="btn btn-primary" type="submit" value="Update Profile" name="submit">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!---------------  user profile end ------------ -->

        </div>
    </div>
  

<?php include('footer.php'); ?>
    
    
