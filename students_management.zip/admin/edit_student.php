<?php
include('head.php');
include('../database.php');
// include('check_login.php');


if(isset($_GET['id'])){
    $id = $_GET['id'];
    $seleteStudent="SELECT * FROM `student` WHERE `id` = '$id'";
    $result = $conn->query($seleteStudent);
    $row = mysqli_fetch_assoc($result);

    
}
    
    


 if(isset($_POST['edit_submit'])){
    $data = $_POST;
    $name = $data['name'];
    $roll = $data['roll'];
    $city = $data['city'];
    $contact = $data['contact'];
    $class = $data['class'];

    $phone_no_count = strlen($contact);


    if (empty($name)) {
        $name_error ="* This field is required to fill";
    }

    if (empty($roll)) {
        $roll_error ="* This field is required to fill";
    }    
    if (empty($city)) {
        $city_error ="* This field is required to fill";
    }    
    if (empty($contact)) {
        $contact_error ="* This field is required to fill";
    }   
    if (empty($class)) {
        $class_error ="* Select a class";
    } 
    if ($phone_no_count != 11) {
        $contact_error ="* Write a valid number";
    } 
    
    
    if (!empty($name) && !empty($roll) && !empty($city) && !empty($contact) && !empty($class) && ($phone_no_count == 11)){
        $update_query = "UPDATE `student` SET `name`='$name',`roll`='$roll',`city`='$city',`contact`='$contact',`class`='$class' WHERE `id` = '$id'";
        $result = $conn->query($update_query); 
        if($result == true){
            header('location:all_student.php');
        }
    }
}
?>




<body>
    <?php
     include('header.php');
    ?>
     
    <style>
        .editstudent, .editstudent a {
            color: #fff;
            background-color: #006DCB;
            border: none;
        }
    </style>
    <div class="row m-0">
        <?php include('sidebar.php');?>
        <div class="col-sm-12 col-md-8 col-lg-9">
            <!--------------- add student start -------------->
        <section class="add-student section">
            <div class="section_title">
                <h4><span><i class="fa-solid fa-user-plus"></i>Edit Students</span>Edit Students</h4>
            </div>
            <div class="row">
                <div class="col-md-12 col-lg-6">
                    <div class="form-container">
                        <form method="POST" enctype="multipart/form-data">
                            <div>
                                <label>Student Name:</label>
                                <div class="text-danger"><?php if (isset($name_error)){echo($name_error);}?></div>
                                <input type="text" id="student-name" placeholder="Student Name" name="name" value="<?php echo $row['name'];?>">
                            </div>
                
                            <div>
                                <label>Student Roll:</label>
                                <div class="text-danger"><?php if (isset($roll_error)){echo($roll_error);}?></div>
                                <input type="text" id="student-roll" placeholder="Student Roll" name="roll" value="<?php echo $row['roll'];?>">
                            </div>
                
                            <div>
                                <label>City Name:</label>
                                <div class="text-danger"><?php if (isset($city_error)){echo($city_error);}?></div>
                                <input type="text" id="city-name" placeholder="City" name="city" value="<?php echo $row['city'];?>">
                            </div>
                
                            <div>
                                <label>Personal Contact:</label>
                                <div class="text-danger"><?php if (isset($contact_error)){echo($contact_error);}?></div>
                                <input type="text" id="contact" placeholder="Personal Contact" name="contact" value="<?php  echo $row['contact'];?>">
                            </div>
                
                            <p>We'll never share your contact number with anyone else</p>
                
                            <div>
                                <label>Class:</label>
                                <div class="text-danger"><?php if (isset($class_error)){echo($class_error);}?></div>
                                <select name="class" value="<?php echo $row['class'];?>">
                                    <option value="">Select Class</option>
                                    <option value="1" <?php if (isset($class) && $class == 1){echo('selected');}?>>6</option>
                                    <option value="2" <?php if (isset($class) && $class == 2){echo('selected');}?>>7</option>
                                    <option value="3" <?php if (isset($class) && $class == 3){echo('selected');}?>>8</option>
                                </select>
                            </div>
    
                            
                
                            <div>
                                <!-- <button class="btn btn-primary"><input type="submit" name="submit"> Add Student</button> -->
                                 <input class="btn btn-primary" type="submit" value="Update" name="edit_submit">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!--------------- add student end -------------->

        </div>
    </div>
  


    
<?php include('footer.php'); ?>