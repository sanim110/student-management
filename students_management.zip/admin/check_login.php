<?php


if(!$_SESSION['admin_logined']){
    header('location: login_page.php');
}

?>