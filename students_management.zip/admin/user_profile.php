
<?php
     include('head.php');
     include('../database.php');

$current_user = $_SESSION['admin_logined'];
$userQuery = "SELECT * FROM `user` WHERE `user_name` = '$current_user'";
$result = $conn->query($userQuery);
$row = mysqli_fetch_assoc($result);

?>
<body>
    <style>
        .user-profile_bar{
            background: gainsboro;
        }
    </style>
    <?php
     include('header.php');
    ?>
     
    <div class="row m-0">
        <?php include('sidebar.php');?>
        <div class="col-sm-12 col-md-8 col-lg-9">
            <!-- ------------- user profile start -------------->
        <section class="user-profile section">
            <div class="section_title">
                <h4><span><i class="fa-solid fa-user"></i>User Profile</span>User Profile</h4>
            </div>
            <div class="user-profile_bar">
                <h5 class="text-center">About You</h5>
            </div>
            <div class="row">
                <div class="col-md-12 col-lg-6">
                    <div class="form-container">
                        <form method="POST">
                        <div class="profile-section">
                            <table class="profile-table">
                                <tr>
                                    <th>User ID</th>
                                    <td><?php print_r($row['id']); ?></td>
                                </tr>
                                <tr>
                                    <th>Name</th>
                                    <td><?php print_r($row['name']); ?></td>
                                </tr>
                                <tr>
                                    <th>User Name</th>
                                    <td><?php print_r($row['user_name']); ?></td>
                                </tr>
                                <tr>
                                    <th>Email</th>
                                    <td><?php print_r($row['email']); ?></td>
                                </tr>
                                <tr>
                                    <th>Status</th>
                                    <td>Active</td>
                                </tr>
                                <tr>
                                    <th>Signup Date</th>
                                    <td><?php print_r($row['created_at']); ?></td>
                                </tr>
                            </table>
                        </div>
                            <div>
                                 <a href="edit_profile.php?id=<?php echo ($row['id']); ?>" class="btn btn-primary">Edit Profile</a>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-12 col-lg-6">
                    <div class="upload-section">
                        <img id="preview" src="https://via.placeholder.com/150" alt="Preview" />
                        <div>
                            <label for="profile-picture">Choose Picture:</label>
                            <input type="file" id="profile-picture" accept="image/*">
                        </div>
                        <div>
                            <!-- <button class="btn btn-primary"><input type="submit" name="submit"> Add Student</button> -->
                            <input class="btn btn-primary" type="submit" value="Upload" name="submit">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!---------------  user profile end ------------ -->

        </div>
    </div>
  


    
<?php include('footer.php'); ?>