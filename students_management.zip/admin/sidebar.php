<div class="col-sm-12 col-md-4 col-lg-3">
    <!-------------- aside area start ---------------------->
    <div class="aside ">
        <ul class="nav">
            <li class="dashbor"><a href="index.php"><i class="fa-solid fa-gauge-high"></i> Dashbord</a></li>
            <li class="addstudent"><a href="add_student.php"><i class="fa-solid fa-user-plus"></i> Add Student</a></li>
            <li class="allstudent"><a href="all_student.php"><i class="fa-solid fa-user-graduate"></i> All Student</a></li>
            <li class="alluser"><a href="all_user.php"><i class="fa-solid fa-users"></i> All user</a></li>
        </ul>
    </div>
    <!-------------- aside area end ---------------------->
</div>