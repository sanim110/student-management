<!-------------- header area start ---------------------->
<header>
        <nav class="bg-light">
            <div class="row d-flex justify-content-center align-items-center">
                <div class="col-md-6">
                    <div class="nav_name">
                        <h2>Student's Management System</h2>
                    </div>
                </div>
                <div class="col-md-6 d-flex justify-content-end align-items-center">
                    <div class="nav_panel">
                        <ul class="d-flex">
                            <li><a href="#"><span><i class="fa-solid fa-user"></i></span>Welcome <?php echo $_SESSION['admin_logined']?></a></li>
                            <li><a href="user_profile.php"><span><i class="fa-solid fa-user"></i></span>Profile</a></li>
                            <li><a href="logout.php"><span><i class="fa-solid fa-power-off"></i></span>Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <!-------------- header area end ---------------------->