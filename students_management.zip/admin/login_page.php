<?php
     include('head.php');
     include('../database.php');
     
?>
<body>
    <h2 class="text-center fw-bold mt-5">Welcome to Students Management System</h2>
    <h3 class="text-center mt-5">Admin Login Form</h3>

    
    <div class="text-center text-danger">
    <?php
    if(isset($_SESSION['matching_error'])){
        echo $_SESSION['matching_error'];
    }
    ?>
    </div>
    
    
    <div class="row d-flex justify-content-center align-items-center">
    <div class="col-sm-12 col-md-4 col-lg-6">
        <div class="form-container">
            <form action="/action/login.php" method="POST">
                <div>
                    <div><?php if (isset($name_error)){echo($name_error);}?></div>
                                
                    <input type="text" id="student-name" placeholder="Username" name="username">
                </div>
                
               
                <div>
                    <div><?php if (isset($contact_error)){echo($contact_error);}?></div>
                    <input type="password" id="contact" placeholder="Password" name="password">
                </div>

                
    
                
                
                <div class="d-flex justify-content-between">
                    <p class="text-start">If you don't have an account? Then please <a href="../index.php">click here for Registration</a></p>
                    <input class="btn btn-primary" type="submit" value="Login" name="submit">
                </div>
                
            </form>
        </div> 
    </div>
    </div>


    
  


<?php include('footer.php'); ?>