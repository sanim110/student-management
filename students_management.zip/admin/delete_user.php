<?php

include('../database.php');

$id = $_GET['id'];
$delet = "DELETE FROM `user` WHERE `id` = '$id'";
$result = $conn->query($delet);
if($result = true){
    header('location:all_user.php');
}
?>

