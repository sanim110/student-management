<?php
    include('head.php');
    include('../database.php');

    $username = $_SESSION['admin_logined'];
    $current_admin = "SELECT * FROM `user` WHERE `user_name` = '$username'";
    $result = $conn->query($current_admin);
    $admin = mysqli_fetch_assoc($result);
    $permission = $admin['is_admin'];
    
?>
<body>
    <?php
     include('header.php');
    ?>
    <style>
        .allstudent, .allstudent a {
            color: #fff;
            background-color: #006DCB;
            border: none;
        }
    </style>

    <div class="row m-0">
        <?php include('sidebar.php');?>
        <div class="col-sm-12 col-md-8 col-lg-9">
            <!--------------- all student start -------------->
        <section class="all-student section" id="all-student">
            <div class="section_title">
                <h4><span><i class="fa-solid fa-users"></i>All Students</span>All Students</h4>
            </div>
            <div class="table-container">
                <h4>All Students</h4>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Roll</th>
                            <th>Class</th>
                            <th>City</th>
                            <th>Contact</th>
                            <th>Photo</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $students ="SELECT * FROM `student`";
                        $all_students = $conn->query($students);
                        while ($row = mysqli_fetch_assoc($all_students)){
                            
                        
                        ?>
                        <tr>
                            <td><?php echo ($row['id']); ?></td>
                            <td><?php echo ($row['name']); ?></td>
                            <td><?php echo ($row['roll']); ?></td>
                            <td><?php echo ($row['class']); ?></td>
                            <td><?php echo ($row['city']); ?></td>
                            <td><?php echo ($row['contact']); ?></td>
                            <td><img width="100px" src="img/<?php echo ($row['photo']); ?>"></td>
                            <?php
                            if($permission == true){
                                ?>
                                <td>
                                    <div class="mb-1"><a href="edit_student.php?id=<?php echo ($row['id']); ?>"><button class="btn btn-primary">Edit</button></a></div>
                                    <div><a onclick="handleDeleteConfirmation(<?php echo ($row['id']); ?>)"><button class="btn btn-danger">Delete</button></a></div>
                                </td>
                                <?php
                            }else{
                                ?>
                                <td>-</td>
                                <?php
                                
                            }
                            ?>
                            
                        </tr>
                        <?php
                         }
                        ?>
                    </tbody>
                </table>
            </div>
        </section>
        <!--------------- all student end -------------->

        </div>
    </div>
  <script>
        function handleDeleteConfirmation(id){
        Swal.fire({
            title: "Do you want to save the changes?",
            showDenyButton: false,
            showCancelButton: true,
            confirmButtonText: "Delete",
        }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
            Swal.fire("Delete Successfull!", "", "success");
            redirectSomeTimeLater(id);
        }
     });

      }
      function redirectSomeTimeLater(id){
          setTimeout(function(){
            window.location.href="delete_student.php?id="+id;
          },2000);
      }
  </script>


    
    
<?php include('footer.php'); ?>
 