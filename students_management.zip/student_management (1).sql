-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2025 at 06:37 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `roll` int(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `photo` text NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `roll`, `city`, `contact`, `class`, `photo`, `create_at`, `update_at`) VALUES
(15, 'sanim', 10, 'khulna', '01742543790', '2', '170425015325.jpg', '2025-04-17 11:53:25', '2025-04-17 11:53:25'),
(16, 'sssdfd', 107, 'khulna1', '09827634673', '2', '170425015401.jpg', '2025-04-17 11:54:01', '2025-04-17 11:54:01'),
(17, 'asfdadf', 103, 'khulnas', '24252352333', '1', '170425015444.', '2025-04-17 11:54:44', '2025-04-17 11:54:44'),
(18, 'sanim1', 21, 'khulna3', '014xxxxxxxx', '2', '170425015512.jpg', '2025-04-17 11:55:12', '2025-04-17 11:55:12');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `photo` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `user_name`, `password`, `is_admin`, `photo`, `created_at`, `updated_at`) VALUES
(17, 'sanim11', 'sanim.sikder.58@gmail.com1', 'sanim', 'd243def5664e80cfa7fc9ffb375a90e1', 0, '', '2025-04-17 11:50:20', '2025-04-17 11:50:20'),
(18, 'sssdfd', 'sanim.sikder.58@gmail.com', 'anjont', '30e535568de1f9231e7d9df0f4a5a44d', 0, '', '2025-04-17 15:46:11', '2025-04-17 15:46:11'),
(19, 'sanim', 'sanim.sikder.58@gmail.com', 'anjon', 'd243def5664e80cfa7fc9ffb375a90e1', 0, '', '2025-04-17 15:50:32', '2025-04-17 15:50:32'),
(20, 'hello', 'sanim.siksfs3223der.58@gmail.com', 'hello', 'af2551abeadc76e3c82278f02ccd4abb', 0, '', '2025-04-17 15:52:54', '2025-04-17 15:52:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
