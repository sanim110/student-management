<?php
session_start();
include('../database.php');


if(isset($_POST['submit'])){
    $data = $_POST;
    $username = $data['username'];
    $password = md5($data['password']);


    $matchingQuery = "SELECT * FROM `user` WHERE `user_name` = '$username' AND `password` = '$password'";
    $result = $conn->query($matchingQuery);
    $count = mysqli_num_rows($result);
    
    if($count == true){
        $_SESSION['admin_logined'] = $username;
        header('Location:/admin/index.php');
    }else{
        $_SESSION['matching_error'] = 'Username or Password not matched';
        header('Location:/admin/login_page.php');
    }
}
?>