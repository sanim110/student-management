$(document).ready(function(){
    $(".nav li a").click(function(){
        // Remove the active class from all columns
        $(".nav li a").removeClass("active");
        
        // Add the active class to the clicked div
        $(this).addClass("active");
    });
});