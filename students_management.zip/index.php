<?php
session_start();
include('database.php');



 if(isset($_POST['submit'])){
    $data = $_POST;
    $name = $data['name'];
    $email = $data['email'];
    $user = $data['user'];
    $pass = $data['pass'];
    $cpass = $data['cpass'];
    
    $password_count = strlen($pass);

    if (empty($name)) {
        $name_error ="* This field is required to fill";
    }

    if (empty($email)) {
        $email_error ="* This field is required to fill";
    }else{
        $email_match = "SELECT * FROM `user` WHERE `email` = '$email'";
        $result = $conn->query($email_match);
        $count = mysqli_num_rows($result);
        if($count > 0){
            $email_error = '* This email already exist';
        }
    }  
    if (empty($user)) {
        $user_error ="* This field is required to fill";
    }    
    if (empty($pass) || empty($cpass)) {
        $pass_error ="* This field is required to fill";
    }   
    if($pass != $cpass){
        $pass_error ="* Password Not Matched";
    }
    if ($password_count < 8) {
        $pass_error ="* Password must be 8 characters or more, You are using $password_count characters";
    }
    if(isset($_FILES['picture'])){
        $img = $_FILES['picture']['name'];
        $explode = explode('.',$img);
        $extension = end($explode);
        $rename = date('dmyhis').'.'.$extension;
    }
    if (!empty($name) && !empty($email) && !empty($user) && !empty($pass) && ($pass === $cpass) && ($password_count >= 8)){
        $pass = md5($pass);
        $insert_query = "INSERT INTO `user`(`name`, `email`, `user_name`, `password`, `photo`) VALUES ('$name','$email','$user','$pass','$rename')";
        // $conn->query($insert_query);   

        $result = $conn->query($insert_query);
        move_uploaded_file($_FILES['picture']['tmp_name'], 'img/'.$rename); 
        if($result == true){
            $_SESSION['admin_logined'] = $user;
            header('Location:admin/index.php');
        }
        else{
            $_SESSION['matching_errorr'] = 'User name already exist';
        }
    }
    
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-------------------- bootstrap's link ------------------>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">


     <!------------------- fontawesome cdn ----------------->
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

     <!---------------------css link ---------------------->
     <link rel="stylesheet" href="assets/css/style.css">
    <title>Home</title>
</head>
<body>
    <h2 class="text-center fw-bold mt-5">Welcome to Students Management System</h2>
    <h3 class="text-center">User Registration Form</h3>
    <div class="row d-flex justify-content-center align-items-center">
        <div class="col-sm-12 col-md-4 col-lg-6">
        <div class="form-container">
            <form method="POST">
                <div>
                    <label>Name:</label>
                    <div class="text-danger"><?php if (isset($name_error)){echo($name_error);}?></div>       
                    <input type="text" id="student-name" placeholder="Write Your Name" name="name" value="<?php if (isset($name)){echo($name);}?>">
                </div>
                
                <div>
                    <label>Email:</label>
                    <div class="text-danger"><?php if (isset($email_error)){echo($email_error);}?></div>
                    <input type="email" id="student-roll" placeholder="Write Your Email" name="email" value="<?php if (isset($email)){echo($email);}?>">
                </div>
                
                <div>
                    <label>User Name:</label>
                    <div class="text-danger">
                        <?php
                            if(isset($_SESSION['matching_errorr'])){echo $_SESSION['matching_errorr'];}
                        ?>
                    </div>
                    <div class="text-danger"><?php if (isset($user_error)){echo($user_error);}?></div>
                    <input type="text" id="city-name" placeholder="Write Your Username" name="user" value="<?php if (isset($user)){echo($user);}?>">
                </div>
                
                <div>
                    <label>Password:</label>
                    <div class="text-danger"><?php if (isset($pass_error)){echo($pass_error);}?></div>
                    <input type="password" id="contact" placeholder="Password" name="pass" value="<?php if (isset($pass)){echo($pass);}?>">
                </div>

                <div>
                    <label>Confirm Password:</label>
                    <div class="text-danger"><?php if (isset($pass_error)){echo($pass_error);}?></div>
                    <input type="password" id="contact" placeholder="Confirm Password" name="cpass" value="<?php if (isset($cpass)){echo($cpass);}?>">
                </div>
    
                <div>
                    <label>Choose Picture:</label>
                    <input type="file" name="picture" id="profile-picture" accept="image/*">
                </div>
                
                <div>
                    <input class="btn btn-primary" type="submit" value="Registration" name="submit">
                </div>
                <p class="text-start">If you already have an account? Then <a href="/admin/login_page.php">click here for Login</a></p>
            </form>
        </div> 
        </div>
    </div>
    
                           
  


    
    
   <!-- js file -->
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
   
   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   <script src="script.js"></script>

</body>
</html>