
<?php
$host_name = "localhost";
$user_name ="root";
$password ="";
$database_name ="student_management";

$conn = new mysqli($host_name, $user_name, $password, $database_name);
// if($conn == true){
//     echo 'connection successfull';
// }

?>